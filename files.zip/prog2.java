
/**
 * Write a description of class prog2 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class prog2

{public void main()
    {Scanner s= new Scanner(System.in);
  System.out.println("Select the Floor Number"); /**Giving Options to User**/
  System.out.println("Ground Floor(a)");
  System.out.println("First Floor(b)");
  System.out.println("Second Floor(c)");
  System.out.println("Third Floor(d)");
  System.out.println("Enter the Floor Number(a,b,c,d)");
  char f = s.next().charAt(0);
  switch(f)
 { case 'a': 
     System.out.println("You have Shopped at the Kids Wear"); /**Writing Different Statements for different Options**/
 break;
 case 'b' :System.out.println("You have Shopped at Ladies Wear");
 break;
 case 'c' :System.out.println("You have Shopped at Designer Wear");
 break;
 case 'd' : System.out.println("You have Shopped at Men's Wear");
 break;
 default :System.out.println("Invalid option");
}

    System.out.println("Name of the Shop: City Mart");
    System.out.println("Amount: ");      /**Displaying Results and the amount**/
    double amt= s.nextDouble();
    System.out.println("Visit Again!!");
    
}}

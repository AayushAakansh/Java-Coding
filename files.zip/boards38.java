
/**
 * Write a description of class boards38 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class boards38
{
   public void main()
   {
       Scanner s = new Scanner (System.in);
       int even =0;
       int odd=0;
       int mul4=0;
       int a[]= new int[10];
       for(int i=0; i<10; i++)
       {
           System.out.println("Enter 10 Numbers in the Arrays");
           a[1] = s.nextInt();
           
       }
       for(int j =0; j<10;j++)
       {

           even = even+1;
           if(a[j]%2!=0)
           odd=odd+1;
           if(a[j]%4==0)
           mul4 = mul4+1;
       }
       System.out.println("The Number of Even Numbers are: " +even);
       System.out.println("The Number of Odd Numbers are: " +odd);
       System.out.println("The Number of Multiples of 4 are: " +mul4);
   }
}


/**
 * Write a description of class Done5 here.
 *
 * @author (your name)
 * @
 * version (a version number or a date)
 */
import java.util.*;
public class Done5
{ public void main()
    { Scanner sc= new Scanner(System.in);
        System.out.println("Give a Word: ");
        String s= sc.nextLine();
        int l=s.length();
        char ch;
        String sh="";
        for(int i=0; i<l; i++)
        { ch= s.charAt(i);
             sh= sh+ch;
        
        System.out.println(sh);
    }
}}

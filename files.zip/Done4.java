
/**
 * Write a description of class Done4 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class Done4
{ public void main()
    {Scanner s = new Scanner(System.in);
        System.out.println("Enter a Number: ");
        int num= s.nextInt();
        int d, sum=0;
        do
        { d= num%10;
            sum= sum+d*d*d;
            num=num/10;
        }
        while(num!=0);
        if(sum==num)
        System.out.println("It is an Armstrong Number");
        else
        System.out.println("It is not an Armstrong Number");
    }
    
}

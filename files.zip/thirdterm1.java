
/**
 * Write a description of class thirdterm1 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class thirdterm1
{ public void main()
    { Scanner s = new Scanner(System.in);
      
        for(int i=1; i<=10; i++)
        {System.out.println(i);
        }}
    
}

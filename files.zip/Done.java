
/**
 * Write a description of class Done here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class Done
{
    public void main()
    { Scanner s = new Scanner(System.in);
        System.out.println("Enter the Basic Pay of the Employee: ");
        double pay= s.nextDouble();
        double dear_allow_ = 0.25*pay;
        double rent = 0.15*pay;
        double prov_fund_ = 0.0833*pay;
        double NetPay= pay + dear_allow_ + rent;
        double GrossPay= NetPay- prov_fund_;
        
        System.out.println("The Net Pay of the Employee is: " +NetPay);
        System.out.println("The Gross Pay of the Employee is: " +GrossPay);
    }
}

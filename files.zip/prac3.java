
/**
 * Write a description of class prac3 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class prac3
{ 
    public void main()
    {Scanner s= new Scanner(System.in);
        System.out.println("Total cost of the Purchase");
        double pur=s.nextDouble();
        double d=0,amt=0;
        
        if(pur<=2000)
        { d=0.05*pur;
            System.out.println("Assured Gift is Wall Clock");
        }
        if(pur>2000 && pur<=5000)
        { d=0.1*pur;
            System.out.println("Assured GIft is School Bag");
        }
        if(pur>5000 && pur<=10000)
        { d=0.15*pur;
            System.out.println("Assured Gift is Electric Iron");
        }
        if(pur>10000)
        { d=0.2*pur;
            System.out.println("Assured Gift is Wrist Watch");
        }
        amt=pur-d;
        System.out.println("Total Cost Of Purchase = " +pur);
        System.out.println("Discount on the Purchase = " +d);
        System.out.println("Amount after Discount = " +amt);
    }
}


/**
 * Write a description of class boards45 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class boards45
{
    public void main()
    {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter a Sentence: ");
        String st = s.nextLine();
        String str ="";
        st = ' ' + st;
        int p = st.length();
        char ch;
        char ch1;
        for(int i = 0; i<p; i++)
        {
            ch = st.charAt(i);
            if(ch == ' ')
            {
                ch1 = st.charAt(i+1);
            str = str +" " + Character.toUpperCase(ch1);
            i=i+1;
            
        }
          else
          str = str+ch;
    }
    System.out.println("The New String: " +str);
    
    }
    
}

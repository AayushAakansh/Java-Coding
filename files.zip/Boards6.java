
/**
 * Write a description of class Boards6 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class Boards6
{ 
    public void main()
    { Scanner s = new Scanner(System.in);
        System.out.println("Enter a Number: ");
        int num = s.nextInt();
        int digit;
        int revnum=0;
         while(num!=0)
         { digit=num%10;
             revnum=revnum*10+digit;
             num = num/10;
            }
            if(revnum==num)
            System.out.println("Number is a Palindrome");
            else
            System.out.println("Number is not a Palindrome");
}}

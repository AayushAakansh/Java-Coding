
/**
 * Write a description of class arrays10 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class arrays10
{
    public void main()
    { Scanner s =new Scanner(System.in);
        int n[]= new int[20];
        int sumeven=0; int sumodd=0;
        for(int i=0;i<20;i++)
        {System.out.println("Enter 20 Numbers for Array:");
            n[i]=s.nextInt();
        }
        for(int j=0;j<20;j++)
        { if(n[j]%2==0)
            sumeven=sumeven+n[j];
            if(n[j]%2!=0)
            sumodd=sumodd+n[j];
        }
        System.out.println("The Sum of Even Numbers is: "+sumeven);
        System.out.println("The Sum of Odd Numbers is: " +sumodd);
    }
            
            
}


/**
 * Write a description of class forloppprog here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class forloppprog
{ public void main()
    {Scanner s= new Scanner(System.in);
   int p=2;
   int q=7;
    {for(int i=100;i<105; i++)
{ q++; --p;
    System.out.println(p);
    System.out.println(q);
      }}}}

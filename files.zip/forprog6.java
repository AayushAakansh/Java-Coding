
/**
 * Write a description of class forprog6 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class forprog6
{ public void main()
    {
    
}

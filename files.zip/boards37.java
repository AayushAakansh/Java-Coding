
/**
 * Write a description of class boards37 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class boards37
{
        Scanner s = new Scanner(System.in);
        int m[] = new int[20];
        
        void arrayTrial()
        {
            
            for(int i = 0; i<=20; i++)
            {
            System.out.println("Enter Numbers in Array: ");
            m[i] = s.nextInt();
            
        }
        int t;
        
        for(int i = 0; i<=20; i++)
        {
            for(int j =0 ; j<=(20-1); j++)
            {
                if(m[j] >m[j+1])
                {
                    t=m[j];
                    m[j] = m[j+1];
                    m[j+1] = t;
                }
            }
        }
        System.out.println("The Sorted Array is: ");
        for(int i=0; i<=20;i++)
        {
            System.out.println(m[i]);
        }
    }
}

    



/**
 * Write a description of class forprog4 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class forprog4
{ public void main()
    { Scanner s= new Scanner(System.in);
        int a,n,sc=0;
        System.out.println("Enter a Number: ");
        n=s.nextInt();
        for(a=1;a<n;a++)
        { if(n%a==0)
            sc=sc+a;
        }
        { if (sc==n) 
            System.out.println(a + "is a Perfect Number");
            else 
            System.out.println(a + "is not a Perfect Number");
        }}
    
}

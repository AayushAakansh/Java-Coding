
/**
 * Write a description of class boards46 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class RailwayTicket
{
    Scanner s = new Scanner(System.in);
    String name;
    String coach;
    long mobno;
    int amt;
    int totalamt;
    RailwayTicket()
    {
        name="";
        coach="";
        mobno = 0L;
        amt=0;
        totalamt=0;
        
    }
    void accept()
    {
        System.out.println("Enter Name of passenger: ");
        name = s.next();
        System.out.println("Enter Coach Type: ");
        coach = s.next();
        System.out.println("Mobile Number: ");
        mobno = s.nextLong();
        System.out.println("Enter Amount: ");
        amt = s.nextInt();
    }
    void update()
    {
        if(coach.equals("First_AC")==true)
        totalamt = amt+700;
        else if(coach.equals("Second_AC")==true)
        totalamt=amt+500;
        else if(coach.equals("Third_AC")==true)
        totalamt=amt+250;
        else if(coach.equals("Sleeper")==true)
        totalamt=amt;
        
    }
    void display()
    {
        System.out.println("The Name of the Passenger is " +name + "  " + "Coach Type Chosen: " +coach + "  " + "Total Amount: " +totalamt + "  " + "Mobile Number: " +mobno);
    }
    public void main()
    {
        RailwayTicket ob = new RailwayTicket();
        ob.accept();
        ob.update();
        ob.display();
    }
}

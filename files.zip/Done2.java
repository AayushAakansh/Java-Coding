
/**
 * Write a description of class Done2 here.
 * Niven Number or Not????????????
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class Done2
{ public void main()
    { Scanner s = new Scanner(System.in);
        System.out.println("Enter a Number: ");
        int num = s.nextInt();
        int sum=0,d,p;
        do
        { d = num%10;
            sum = sum+d;
        num=num/10;
    }
    while(num!=0);
    
    if(num%sum==0)
        System.out.println("It is a Niven Number");
        else
        System.out.println("It is not a Niven Number");
    }
    
}

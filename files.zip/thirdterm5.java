
/**
 * Write a description of class thirdterm5 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class thirdterm5
{public void main()
    {Scanner s= new Scanner(System.in);
        System.out.println("Enter Number 1: ");
        int base= s.nextInt();
        System.out.println("Enter Number 2: ");
        int power= s.nextInt();
        int result=1;
        for(int i=1; i<=power; i++)
        { result*=base;} 
        System.out.println("Result is: " +result);
    
}}

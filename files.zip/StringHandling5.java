
/**
 * Write a description of class StringHandling5 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class StringHandling5
{public void main()
    {
    Scanner sc=new Scanner(System.in);
  System.out.println("Enter a Word: ");
  String s=sc.nextLine();
  String s1 = s.replace("MOHANDAS KARAMCHAND GANDHI" ,"GANDHI MOHANDAS KARAMCHAND");
  System.out.println("The New Word is: " +s1);
  
}}


/**
 * Write a description of class exam3 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class exam3
{
    public void main()
    {Scanner s= new Scanner(System.in);
     
        System.out.println("Salary of the Man: ");
        double sal= s.nextDouble();
        double food = 1.0/2*sal;
        double rent= 1.0/15*sal;
        double misce=1.0/10*sal;
        double save=1.0/3*sal;
        System.out.println("Money Spent on Food: " +food);
        System.out.println("Money SPent on Rent: " +rent);
        System.out.println("Money Spent on Miscellaneous: " +misce);
        System.out.println("Money Saved: " +save);
}}

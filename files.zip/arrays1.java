
/**
 * Write a description of class arrays1 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class arrays1
{
    public void main()
    { int n[]= new int[10];
   int k=1;
   for(int i=0;i<9;i++)
   { n[i]=k;
       k++;
    }
    System.out.println(n[k]);
    
}}

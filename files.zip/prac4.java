
/**
 * Write a description of class prac4 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class prac4
{
    public void main()
    {Scanner sc=new Scanner(System.in);
        char c,s,r;
        System.out.println("Area Of Circle(c)");
        System.out.println("Area of Square(s)");
        System.out.println("Area of Rectangle(r)");
        System.out.println("Choose Option c,s,r");
        char opt= sc.next().charAt(0);
        double area = 0;
        double ra,si,l,b;
        switch(opt)
        { case 1: 
            System.out.println("Enter Radius of Circle");
            ra=sc.nextDouble();
            area= 22/7*ra*ra;
            System.out.println("Area of Circle is " +area);
            break;
            case 2:
                System.out.println("Enter Side of Square");
                si=sc.nextDouble();
                area= si*si;
                System.out.println("Area of Square is " +area);   
                break;
            case 3:
                System.out.println("Enter Length and Breadth of Rectangle");
                l=sc.nextDouble();
                b=sc.nextDouble();
                area=l*b;
                System.out.println("Area of Rectangle is " +area);
                break;
            
    
}}}


/**
 * Write a description of class Boards3 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

public class Boards3
{
   public void main()
  { int numsq=0;
   int printno=0;
   
    for(int i=2;i<=11; i++)
       {
           numsq = i*i;
           printno=numsq+1;
           System.out.println(printno + " ");
}}}

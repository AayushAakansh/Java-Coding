
/**
 * Write a description of class arrays7 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class arrays7
{
    public void main()
    { Scanner s =new Scanner (System.in);
        int n[]= new int[10];
        int sum=0;
        for(int i=0; i<10; i++)
        { System.out.println("Enter a Number in the Array: ");
        n[i]=s.nextInt();
    }
    int length=n.length;
    for(int j=0;j<n.length;j++)
    { if (n[j]%3==0 || n[j]%5==0)
        sum = sum+ n[j];
    }
    System.out.println("The Sum is: "+sum);
}
}

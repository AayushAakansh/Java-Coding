
/**
 * Write a description of class note here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class note
{
    Linear Search	Binary Search
Linear search works on sorted and unsorted arrays        	Binary search works on only sorted arrays (ascending or descending)
Each element of the array is checked against the target value until the element is found or end of the array is reached	       Array is successively divided into 2 halves and the target element is searched either in the first half or in the second half
Linear Search is slower	        Binary Search is faster
}

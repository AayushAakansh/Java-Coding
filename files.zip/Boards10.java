
/**
 * Write a description of class Boards10 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class Boards10
{
    public void main()
    { Scanner s = new Scanner(System.in);
        System.out.println("Enter Number 1: ");
        int num1 = s.nextInt();
        System.out.println("Enter Number 2: ");
        int num2 = s.nextInt();
        System.out.println("Enter Number 3: ");
        int num3 = s.nextInt();
        
        if(num1>num2)
        { if(num1>num3)
            System.out.println("Number 1 is the Greatest");
        }
        if(num2>num3)
        { if(num2>num1)
            System.out.println("Number 2 is the Greatest");
        }
        if(num3>num1)
        { if(num3>num2)
            System.out.println("Number 3 is the Greatest");
        }
    }
}

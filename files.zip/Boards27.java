
/**
Write a program to enter a sentence.
Calculate total Vowel, Space, Consonant, and word.
 */
import java.util.*;
public class Boards27
{ 
    public void main()
    {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter a Sentence in Upper Case: ");
        String st = s.next();
        int l = st.length();
        int vowel=0;
        int space=0;
        int consonant=0;
        char ch;
        for(int i=0; i<=l; i++)
        {
            ch = st.charAt(i);
            if(ch== 'A' || ch=='E' || ch=='I' || ch=='O' || ch=='U')
            vowel++;
            else if(ch==' ')
            space++;
            
            consonant = l - (vowel+space);
        }
        System.out.println("The Number of Vowels are: " +vowel);
        System.out.println("The Number of Consonants are: " +consonant);
        System.out.println("The Number of Spaces are: " +space);
        System.out.println("The Total Number of Words are: " +(space+1));
            
        }
    }
    



/**
 * Write a description of class assignment3 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class assignment3
{
    public void main()
    { Scanner s = new Scanner(System.in);
        System.out.println("Enter a Number: ");
        int num = s.nextInt();
    boolean flag = false;
    for (int i = 2; i <= num / 2; ++i) {
      // condition for nonprime number
      if (num % i == 0) {
        flag = true;
        break;
      }
    }

    if (!flag)              //printing the results
      System.out.println(num + " is a prime number.");
    else
      System.out.println(num + " is not a prime number.");
 if (num == 1) {
            System.out.println(num + " is not a twisted prime number");
        }
        else {
            boolean isPrime = true;   //checking if the number is twisted prime or not
            for (int i = 2; i <= num / 2; i++) {
                if (num % i == 0) {
                    isPrime = false;
                    break;
                }
            }
            
            if (isPrime) {
                
                int t = num;      //reversing the digits
                int revNum = 0;
                
                while (t != 0) {
                    int digit = t % 10;
                    t /= 10;
                    revNum = revNum * 10 + digit;
                }
                
                for (int i = 2; i <= revNum / 2; i++) {
                    if (revNum % i == 0) {
                        isPrime = false;
                        break;
                    }
                }
            }
            
            if (isPrime)  //printing the results
                    System.out.println(num + " is a twisted prime number");
                else
                    System.out.println(num + " is not a twisted prime number");
    
    
    }
}}


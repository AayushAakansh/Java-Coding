
/**
 * Write a description of class assign1 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class assign1
{public void main()
    { Scanner s= new Scanner(System.in);
  System.out.println("Enter a Number: ");
  int num = s.nextInt();
  int prod=1;
  System.out.print("Factorial is ");
  for(int i=1; i<=num; i++)
  { 
      prod=prod*i;
      System.out.print(prod+",");
}}}


/**
 * Write a description of class arrays2 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class arrays2
{
    public void main()
    { Scanner s= new Scanner(System.in);
        
        int n[]=new int [10];
        int sum=0;
        for(int i=0;i<10;i++)
        { System.out.println("Give the Nos in the Aaray(10 Numbers):");
            n[i]=s.nextInt();
            sum=sum+n[i];
        }
        System.out.println("The sum is" +sum);
    }
    
}

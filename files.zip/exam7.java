
/**
 * Write a description of class exam7 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class exam7
{ public void main()
    {Scanner s = new Scanner(System.in);
        System.out.println("Number of Units Consumed: ");
        double unit = s.nextDouble();
       System.out.println("Name of the Consumer:");
       String name= s.nextLine();
       System.out.println("Consumer's Number");
       int num= s.nextInt();
       
       double amt=0;
       if(unit<=100)
       amt=5.50*unit;
       else if(unit>100 && unit<=300)
       amt= 100*5.50 + (unit-100)*6.50;
       else if(unit>300 && unit<=600)
       amt = 100*5.50+200*6.50+(unit-300)*7.50;
       else if(unit>600)
       amt=100*5.50+200*6.50+300*7.50+(unit-600)*8.50;
       
       System.out.println("The Amount is:" +amt);
    
    }
}

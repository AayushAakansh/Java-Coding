
/**
 * Write a description of class boards39 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class boards39
{
    public void main()
    {
        Scanner s = new Scanner(System.in);
        int m[] = new int[10];
        int ns;
        for(int i = 0 ; i<10; i++)
        {
            System.out.println("Enter Numbers in the Array: ");
            m[i] = s.nextInt();
            
        }
        System.out.println("Enter Number to be Searched:");
        ns = s.nextInt();
        int k=0;
        for(int j =0 ; j<10; j++)
        {
            if(m[j]==ns)
            k=1;
        }
        if(k==1)
        System.out.println("The Number is Present");
        else
        System.out.println("The Number is Not Present");
    }
}

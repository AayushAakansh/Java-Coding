
/**
 * Write a description of class froprog2 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class froprog2
{
    public void main()
    {Scanner s= new Scanner(System.in);
      int a,b,p,i, gcd=0;
      System.out.println("Enter First Number");
     a= s.nextInt();
     b= s.nextInt();
     p=a*b;
     {for(i=1;i<p;i++)
         {if(a%i==0 && b%i==0)
             gcd=i;
             System.out.println("GCD is : " +gcd);
      
}}}}

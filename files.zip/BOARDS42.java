
/**
 * Write a description of class BOARDS42 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class BOARDS42
{
    public void main()
    {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter Full Name: ");
        String st1 = s.nextLine();
        String st="";
        String st2="";
        st1 = ' ' +st1;
        int p = st1.lastIndexOf(' ');
        String sn = st1.substring(p);
        char ch;
        for(int i = 0; i<p; i++)
        {
            ch= st1.charAt(i);
            if(ch==' ')
            st = st + st1.charAt(i+1) + '.';
        }
        st2 = st+sn;
        System.out.println("The Name with Initials is: " +st2);
    }
    
}

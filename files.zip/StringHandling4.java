
/**
 * Write a description of class StringHandling4 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class StringHandling4
{ public void main()
    { Scanner sc=new Scanner(System.in);
      System.out.println("Enter a Sentence in Upper Case: ");
      String s= sc.nextLine();
    int v=0;
      int l =s.length();
      for(int i=0; i<l; i++)
      { char ch=s.charAt(i); 
          if(ch=='A' || ch=='E' || ch=='I' || ch=='O' || ch=='U')
          { v=v+1;
              }}
          System.out.println("The Number of Vowels are: " +v);
          
        
    }
}

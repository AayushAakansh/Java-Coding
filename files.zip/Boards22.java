
/**
 * Write a description of class Boards22 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class Boards22
{
    public void main()
    {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter a Number: ");
        int num = s.nextInt();
        int d;
        int prod=1;
        int sum=0;
        while(num!=0)
        {
            d=num%10;
            prod=prod*d;
            sum=sum+d;
            num=num/10;
        }
        if(num==prod)
        System.out.println("The Number is a Spy Number");
        else
        System.out.println("The Number is not a Spy Number");
    }
    
    
}

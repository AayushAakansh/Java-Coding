
/**
 * Write a description of class boards33 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class numberboards33
{
    private int num;
    numberboards33(int x)
    {
        num=x;
    }
    int reverse(int n)
    {
        int d;
        int rev=0;
        while(n!=0)
        {
            d=n%10;
            rev=rev*10+d;
            n=n/10;
        }
        return(rev);
    }
    void palindrome()
    {
        int k=reverse(num);
        if(k==num)
        System.out.println("The Number is Palindrome");
        else
        System.out.println("The Number is not a Palindrome");
    }
}

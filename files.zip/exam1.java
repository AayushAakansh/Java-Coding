
/**
 * Write a description of class exam1 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class exam1
{
    public void main()
    { Scanner s=new Scanner(System.in);
        System.out.println("Number of Voters = ");
        double num=s.nextInt();
        double voted=0.8*num;
        
        double x=0.6*voted;
        double y=0.4*voted;
        System.out.println("Number of Votes X get is =" +x);
        System.out.println("Number of Votes Y get is =" +y);
        
}}

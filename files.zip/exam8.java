
/**
 * Write a description of class exam8 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class exam8 extends thirdterm9
{ public void main()
    {Scanner s= new Scanner(System.in);
 
        System.out.println("Value of Resistence 1: ");
        double r1= s.nextDouble();
        System.out.println("Value of Resistence 2: ");
        double r2= s.nextDouble();
        System.out.println("Choose Your Option 1. Series 2. Parallel");
        int opt= s.nextInt();
         double R1 , R2;
        switch(opt)
        { case 1:
            R1 = r1+r2;
            System.out.println("Resistence is: " +R1);
            break;
            case 2:
                R2 = (r1*r2)/(r1+r2) ;
                System.out.println("Resistence is: " +R2);
        break;
        default:
            System.out.println("Wrong Option");
        }
     
    
    }}

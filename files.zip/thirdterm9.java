
/**
 * Write a description of class thirdterm9 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class thirdterm9
{public void main()
    {Scanner s = new Scanner(System.in);
        System.out.println("Enter First Number: ");
        int num1= s.nextInt();
        System.out.println("Enter Second Number: ");
        int num2= s.nextInt();
        System.out.println("Enter Third Number: ");
        int num3= s.nextInt();
        
        if(num1>num2)
        {if(num1>num3)
            {System.out.println("Greatest Number is: " +num1);
            }}
             if(num2>num1)
            {if(num2>num3)
                {System.out.println("Greatest Number is: " +num2);
                }}
                if(num3>num1)
                {if(num3>num2)
                    {System.out.println("Greatest Number is: " +num3);
                    }}
    
}}

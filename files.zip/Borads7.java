
/**
 * Write a description of class Borads7 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Borads7
{
   public void main()
   { int sum = 0;
       for(int i=1; i<=10; i++)
       { int p = i;
           for(int j=1; j<=i; j++)
           {
               p=p*j;
               sum=sum+p;
            }}
            System.out.println(sum);
        }
}

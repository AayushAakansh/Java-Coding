
/**
 * Write a description of class exam4 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class exam4
{ public void main()
    {Scanner s = new Scanner(System.in);
        System.out.println("Enter Number 1: ");
        double a= s.nextDouble();
        System.out.println("Enter Number 2: ");
        double b= s.nextDouble();
        System.out.println("Enter Number 3: ");
        double c=s.nextDouble();
        
        double x= 1/Math.pow(a,2) + 2/Math.pow(b,2) + 3/Math.pow(c,2);
        
        System.out.println("The Value Of the Equation is: " +x);
        
    
    }}

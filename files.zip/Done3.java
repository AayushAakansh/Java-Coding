
/**
 * Write a description of class Done3 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class Done3
{public void main()
    {Scanner s = new Scanner(System.in);
        System.out.println("Accept a Number: ");
        int num = s.nextInt();
        int p = num*num;
        int d, sum=0;
        do
        { d = p%10;
            sum = sum+d;
            p=p/10;
        } 
        while(p!=0);
        if(sum==num)
        System.out.println("It is a Neon Number");
        else
        System.out.println("It is not a Neon Number");
    }
}

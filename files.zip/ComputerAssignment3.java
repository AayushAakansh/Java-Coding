
/**
 * Write a description of class ComputerAssignment3 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class ComputerAssignment3
{ public void main()
    { Scanner s = new Scanner(System.in);
        int RN[]= new int[5];
        double SubA[]= new double[5]; //setting up arrays for storing marks for Subject A B and C and for Average
        double SubB[]= new double[5];
        double SubC[]= new double[5];
        double avg[]= new double[5];
        for(int i=0; i<5; i++)
        { System.out.print("Enter Roll Number:");
            RN[i]= s.nextInt(); //accepting the roll no. and marks of 3 subjects of the subjects
            System.out.print("Enter Subject A Marks:");
            SubA[i]= s.nextDouble();
            System.out.print("Enter Subject B Marks:");
            SubB[i]= s.nextDouble();
            System.out.print("Enter SubjectC Marks:");
            SubC[i] = s.nextDouble();
            avg[i]= (SubA[i] + SubB[i] + SubC[i])/3; //calculating average of the marks
        }
            System.out.println("Roll Number:/tAverage:");
            for(int i=0;i<5;i++) //printing the Average along with it Roll No. 
            { System.out.println(RN[i] +"/t" + avg[i]);
            }
            System.out.println("Students With Average Marks above 80: ");
            for(int i=0;i<5;i++) //Checking With Average of all Students 
            { if(avg[i]>80)
                System.out.println(RN[i] + "/t" + avg[i]);
            }
            System.out.println("Students With Average Marks below 40: ");
            for(int i=0;i<5;i++)
            { if(avg[i]<40)
                System.out.println(RN[i] + "/t" + avg[i]);
            }
            
    
}}


/**
 * Write a description of class boards35 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class boards35
{
    String n;
    int h;
    double r;
    double w;
    Scanner s = new Scanner(System.in);
     void get()
     {
         System.out.println("Enter Name of Security Perosnnel: ");
         n = s.nextLine();
         System.out.println("Enter Number of Hours Worked: ");
         h = s.nextInt();
         System.out.println("Enter Rate: ");
         r = s.nextInt();
        
     }
     void calwage()
     {
         if(h<=40)
         w = r*40;
         else if(h>40 && h<=60)
         w = (h-40)*1.5*r + r*40;
         else if(h>60)
         w = (h-60)*2*r + 20*1.5*r + 40*r;
         
     }
     void display()
     {
         System.out.println("The Name of The Personnel" + "/t" + "The Number of Hours worked" + "/t" + "The Wage");
         System.out.println(n + "/t" + h + "/t" + w);
     }
     void main()
     {
         boards35 ob = new boards35();
         ob.get();
         ob.calwage();
         ob.display();
         
     }
}


/**
 * Write a description of class arrays9 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class arrays9
{
    public void main()
    { Scanner s=new Scanner(System.in);
        int n[]=new int[10];
        int k=0;
        for(int i=0;i<10;i++)
        { System.out.println("Enter Numbers in the Array: ");
            n[i]=s.nextInt();
        } 
        System.out.println("Enter Number to be Searched: ");
        int ns= s.nextInt();
        for(int j=0;j<10;j++)
        {if(n[j]==ns)
            k=1;
        }
        if(k==1)
        System.out.println("The Number is Present");
        else
        System.out.println("The Number is not Present");
    }
}

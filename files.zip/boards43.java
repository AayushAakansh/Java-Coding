
/**
 * Write a description of class boards43 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class boards43
{
    public void main()
    {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter a Word: ");
        String st = s.next();
        String st1="";
        char ch;
        int l = st.length();
        for(int i=l-1; i>=0;i--)
        {
            ch=st.charAt(i);
            st1=st1+ch;
        }
        if(st.equals(st1))
        System.out.println("The Word is a Palindrome");
        else
        System.out.println("The Word is not a Palindrome");
    }
    
}

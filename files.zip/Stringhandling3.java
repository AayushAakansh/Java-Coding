
/**
 * Write a description of class Stringhandling3 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class Stringhandling3
{ public void main()
    {Scanner sc= new Scanner(System.in);
  System.out.println("Enter a String Value: ");
  String s=sc.nextLine();
  String p = s.toLowerCase();
  String sl="";
  int l=p.length();
  for(int i=0; i<l; i++)
  { char ch= s.charAt(i);
      sl= sl+ch;}
      if(p.equals(sl))
      { System.out.println("It is a Palindrome Word");
        }else
          { System.out.println("It is not a Palindrome Word");
            }}}
    


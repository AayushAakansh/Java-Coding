
/**
 * Write a description of class switchcase2 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class switchcase2
{
    public void main()
    
{
    Scanner sc= new Scanner(System.in);
    System.out.println("Enter Alphabet");
    char alpha= sc.next().charAt(0);
    switch(alpha)
    {
        case 
    }
}
}

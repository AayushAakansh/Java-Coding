
/**
 * Write a description of class forprog5 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class forprog5
{ public void main()
    {Scanner s= new Scanner(System.in);
        int i;
        int sum=0;
        for(i=1;i<=100;i++)
        { sum= sum+i;
            System.out.println("Sum of Natural numbers from 1 to 100 is: " +sum);
        }}
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}


/**
 * Write a description of class arrays6 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class arrays6
{
    public void main()
    { int n[] = {44,2,4,3,55,65,4,1,12,5};
    int length=n.length;
    int min=n[0];
    for(int i=0;i<n.length;i++)
    { if(n[i]<min)
        { n[i]=min;
        }}
        System.out.println("The Minimum Number is: " +min);
    }
        
}


/**
 * Write a description of class arrays11 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class arrays11
{
    public void main()
    { Scanner s = new Scanner(System.in);
        int n[]=new int[10];
        int temp;
        for(int i=0;i<10;i++)
        { System.out.println("Enter Temperature in Fahrenheit:");
            n[i]=s.nextInt();
        }
        for(int j=0;j<10;j++)
        { temp= (n[j]-32/9)*5;
        }
        System.out.println("The Temperatures in Celcius are:");
        for(int p=0;p<10;p++)
        System.out.println(n[p]);
    }
        
}

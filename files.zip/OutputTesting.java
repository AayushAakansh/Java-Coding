
/**
 * Write a description of class OutputTesting here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class OutputTesting



{
    public void main()
    {
        for(int p=100; p>=10; p=p-20)
        {
            System.out.println(p);
        }
    }
}


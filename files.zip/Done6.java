
/**
 * Write a description of class Done6 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */import java.util.*;
public class Done6
{
    public void main()
    { Scanner sc=new Scanner(System.in);
        System.out.println("Enter a Word: ");
        String s=sc.nextLine();
        int l= s.length();
    int p=0;
        for(int i=0; i<l; i++)
        { char ch=s.charAt(i);
            if(ch=='A'||ch=='E'||ch=='I'||ch=='O'||ch=='U')
            p=s.indexOf(ch) +1;
        }
        System.out.println("The First Vowel is on: " +p);
        
        if(p==0)
        System.out.println("There are no vowels");
}}

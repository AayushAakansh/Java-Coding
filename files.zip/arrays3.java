
/**
 * Write a description of class arrays3 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */import java.util.*;
public class arrays3
{
    public void main()
   { Scanner s=new Scanner(System.in);
       int sum=0;
     int n[]= new int[10];
     for(int j=0;j<10;j++)
     { System.out.println("Enter a Number in Array: ");
         n[j]= s.nextInt(); }
    int length=n.length;
    for(int i=0;i<n.length;i++)
    { if(n[i]%2==0)
        { sum=sum+n[i];
    
}}
System.out.println("THe sum is :" +sum);
}}

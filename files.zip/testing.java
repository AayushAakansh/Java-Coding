
/**
 * Write a description of class testing here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class testing
{public void main()
{

String str = "Information Technology";
int p;
p = str.indexOf('n');
System.out.print(p);
System.out.println(str);



}}


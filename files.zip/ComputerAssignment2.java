
/**
 * Write a description of class ComputerAssignment2 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class ComputerAssignment2
{ private String bname;
    private double price;
    
    public ComputerAssignment2() {
        bname = "";     //assigning a variable for book name and its cost
        price = 0.0;
    }
    
    public void input() {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter name of the book: ");
        bname = in.nextLine(); // accepting name of book and its cost from user
        System.out.print("Enter price of the book: ");
        price = in.nextDouble();
    }
    
    public void calculate() {
        double disc;
        if (price <= 1000) //setting up conditions for different prices of he book
            disc = price * 0.02; //calculating necessary discounts 
        else if (price <= 3000)
            disc = price * 0.1;
        else
            disc = price * 0.15;
            
        price = price-disc;
    }
    
    public void display() {
        System.out.println("Book Name: " + bname); //a new method for displaying name of book and its cost
        System.out.println("Price after discount: " + price);
    }
    
    public static void main(String args[]) {
        ComputerAssignment2 obj = new ComputerAssignment2();
        obj.input();
        obj.calculate();
        obj.display();
    }
}
    

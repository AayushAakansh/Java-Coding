
/**
 * Write a description of class Stringhandling2 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class Stringhandling2
 
{
   public void main()
   {Scanner sc=new Scanner(System.in);
       System.out.println("Enter a String: ");
       String s= sc.nextLine();
       String uc = s.toUpperCase();
       char ch=' ';
       String sl="";
       int l= uc.length();
       for(int i=0; i<l; i++)
       { for(int j=0; j<=i; j++)
            ch = uc.charAt(j);
            sl = sl+ch;
           System.out.println(sl);
        }
}}

/**
 * Write a description of class arrays8 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class arrays8
{
    public void main()
    { int n[]= {43,45,92,87,64,76,81,65,12,31};
    int max=n[0];
    int min=n[0];
    for(int i=0;i<10;i++)
    {if(n[i]>max)
        max=n[i];
        if(n[i]<min)
        min=n[i];
    } 
    System.out.println("The Largest Number is: " +max);
    System.out.println("The Smallest Number is: " +min);
}
}

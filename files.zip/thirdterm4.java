
/**
 * Write a description of class thirdterm4 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class thirdterm4
{ public void main()
    { Scanner s= new Scanner (System.in);
      System.out.println("Enter a Number: ");
      int num= s.nextInt();
      int fact=1;
      for(int i=1; i<=num; i++)
      { fact=i*fact;
        }
        System.out.println("Factorial of the number is: " +fact);
    
}}

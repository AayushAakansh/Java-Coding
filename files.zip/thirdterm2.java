
/**
 * Write a description of class thirdterm2 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class thirdterm2
{ public void main()
    { Scanner s = new Scanner(System.in);
      int sum=0;
      int i;
      for(i=1; i<=10; i++)
      { sum+=i; }
    System.out.println("Sum is: " +sum);
}
}

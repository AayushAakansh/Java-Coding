
/**
 * Write a description of class CHat here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class CHat
{
    public void main()
    {
    System.out.println("F in The Chat For Rishit");
}
}

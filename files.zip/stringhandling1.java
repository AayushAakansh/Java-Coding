
/**
 * Write a description of class stringhandling1 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class stringhandling1
{
   public void main()
   {Scanner sc=new Scanner(System.in);
       System.out.println("Enter a String: ");
       String s= sc.nextLine();
       String uc = s.toUpperCase();
       int l= uc.length();
       for(int i=0; i<l; i++)
       { char ch = uc.charAt(i);
           System.out.println(ch);
        }
}}

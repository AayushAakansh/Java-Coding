
/**
 * Write a description of class assignment2 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

public class assignment2
{ public void main()
    {
    for(int i=0; i<=3; i++)
    { for(int j=0; j<=i; j++)
        { 
            System.out.print("*"+" ");
           System.out.print("#");
        }
            System.out.println();
            
        }
}}

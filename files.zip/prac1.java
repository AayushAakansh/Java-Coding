
/**
 * Write a description of class prac1 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class prac1
{ 
    public void main()
    {Scanner s= new Scanner(System.in);
        
    int a,b,c,gn=0,sn=0;
    System.out.println("ENTER THREE NUMBERS BETWEEN 1 TO 9: ");
    a= s.nextInt();
    b=s.nextInt();
    c=s.nextInt();
    
    if (a>b && a>c)
    { if (b>c)
        {gn= 100*a+10*b+c;
            sn= 100*c +10*b+a;
        }
        else 
        { gn=100*a+10*c+b;
            sn = 100*b+10*c+a;
        } } 
        if (b>a && b>c)
        { if (a>c)
            {gn= b*100+a*10+c;
                sn= c*100+a*10+b;}
                else 
                { gn= b*100+10*c+a;
                    sn= c*100+a*10+b;
                }}
                if (c>a && c>b)
                {if (a>b)
                    {gn=c*100+a*10+b;
                        sn=b*100+a*10+c;
                    }
                    else
                    {gn=c*100+b*10+a;
                        sn=a*100+b*10+c;
                    }}
                
               System.out.println("The Greatest Number is =" +gn);
               System.out.println("The Smallest Number is =" +sn);
            }
                
    
}

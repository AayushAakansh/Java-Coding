
/**
 * Write a description of class Boards17 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class Boards17
{
    public void main()
    {
        Scanner s = new Scanner(System.in);
        String st,sn,st1="",st2="";
        int i,p;
        char ch;
        System.out.println("Enter Full Name: ");
        st=s.nextLine();
        st=' ' +st;
        p=st.lastIndexOf(' ');
        sn=st.substring(p);
        for( i=0; i<p;i++)
        {
            ch = st.charAt(i);
            if(ch==' ')
            st1=st1+st.charAt(i+1)+'.';
        }
        st2=st1+sn;
        System.out.println("The Name With Initials is: " +st2);
    }
            
        }
    
    



/**
 A cloth showroom has announced the following festival discounts on the purchase of items
 based on the total cost of the items purchased:
                                    Total cost                                   Discount (in Percentage)
                                    Less than Rs. 2000                                  5%
                                    Rs. 2001 to Rs. 5000                              25%
                                    Rs. 5001 to Rs. 10000                            35%
                                    Above Rs. 10000                                   50%   
 
Write a program to input the total cost and to compute and
 display the amount to be paid by the customer after
 availing the discount.
 Three methods also their input(), calculate() and display().

                                    */
  import java.util.*;                                 
public class Boards26
{
    Scanner s = new Scanner(System.in);
    double cost;
    double discount;
    double amount;
    void input()
    {
        System.out.println("Enter The Total Cost: ");
        cost = s.nextDouble();
    }
    void calculate()
    {
        if(cost<=2000)
        discount = 0.05*cost;
        else if(cost>=2001 && cost<=5000)
        discount = 0.25*cost;
        else if(cost>=5001 && cost<=10000)
        discount = 0.35*cost;
        else if(cost>10000)
        discount = 0.5*cost;
        
        amount = cost-discount;
    
    }
    void display()
    {
        System.out.println("The Total Cost Before Discount is: " +cost);
        System.out.println("The Discount Availed is : " +discount);
        System.out.println("The Amount After the Discount is: " +amount);
    
    }
    public void main()
    {
        Boards26 ob = new Boards26();
        ob.input();
        ob.calculate();
        ob.display();
        
    }
        
    }
    


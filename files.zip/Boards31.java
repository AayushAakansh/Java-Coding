
/**
 * Write a description of class Boards31 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Boards31
{
    
}

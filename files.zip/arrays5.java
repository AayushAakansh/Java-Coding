
/**
 * Write a description of class arrays5 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class arrays5
{
   public void main()
   { int n[]={1,3,2,4,6,5,77,8,92,6,99};
   int length=n.length;
   int max=n[0];
   for(int i=0;i<n.length;i++)
   { if(n[i]>max)
       max=n[i];
    } System.out.println("The MAX Integer is: " +max);
}
}

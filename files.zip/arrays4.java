
/**
 * Write a description of class arrays4 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class arrays4
{
    public void main()
    { Scanner s=new Scanner(System.in);
        int n[]=new int[10];
        for(int i=0;i<10;i++)
        { System.out.println("Enter Numbers in an Array: ");
            n[i]=s.nextInt();
        }
        int length=n.length;
        int multiple=1;
        int sum=0;
        for(int j=0;j<n.length;j++)
        { if(n[j]%7==0)
         multiple=3*n[j];
         sum=sum+multiple;
        }
        System.out.println("The Sum is: "+sum);
    }
            
}

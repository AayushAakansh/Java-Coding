
/**
 * Write a description of class prac2 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class prac2
{
    public void main()
    {Scanner s = new Scanner(System.in);
        System.out.println("Name of the Consumer");
        String name = s.nextLine();
        System.out.println("Phone Number of Consumer");
        double phone= s.nextDouble();
        System.out.println("Units Consumed");
        double unit= s.nextDouble();
        double amt=0;
        if(unit<=100)
        amt = unit*5.50;
        else if(unit>100 && unit <=300)
        amt = 100*5.50+200*6.50+(unit-300)*7.50;
        else if(unit>600)
        amt= 100*5.50+200*6.50+300*7.50+(unit-600)*8.50;
        
        System.out.println("********************************MONEY RECEIPT*********************************");
        System.out.println("Consumer's Number: " +phone);
        System.out.println("Consumer's Name: " +name);
        System.out.println("Units Consumed: " +unit);
        System.out.println("Amounts to be paid: " +amt);
    }
    
    }

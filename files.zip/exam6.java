
/**
 * Write a description of class exam6 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class exam6
{ public void main()
    {Scanner s= new Scanner(System.in);
        System.out.println("Marks In English: ");
        double eng=s.nextDouble();
        System.out.println("Marks In Maths: ");
        double math=s.nextDouble();
        System.out.println("Marks in Science: ");
        double sci=s.nextDouble();
        
    if(eng>=80 && math>=80 && sci>=80)
    System.out.println("Pure Science Stream");
    else if(eng>=80 && sci>=80 && math>=60)
    System.out.println("Bio. Science Stream");
    else if(eng>=60 && math>=60 && sci>=60)
    System.out.println("Commerce Stream");
}
}

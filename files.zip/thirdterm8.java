
/**
 * Write a description of class thirdterm8 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class thirdterm8
{public void main()
    {Scanner s = new Scanner (System.in);
        System.out.println("Enter a Number: ");
        int num = s.nextInt();
        if(num>0)
        {System.out.println("Number is Positive");}
            else if(num<0)
            {System.out.println("Number is Negative");}
            else 
            {System.out.println("Number is 0");}}
                
        
    
}

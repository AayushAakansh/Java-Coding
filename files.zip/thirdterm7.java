
/**
 * Write a description of class thirdterm7 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class thirdterm7
{ public void main()
    {Scanner s = new Scanner(System.in);
        System.out.println("Enter Number of times Series should occur: ");
       int num= s.nextInt();
       double sum = 0;
       for(int i=1; i<=num; i++)
       { sum+=1.0/i;
        }
        System.out.println("sum: " +sum);
    
}}

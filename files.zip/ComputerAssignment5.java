
/**
 * Write a description of class ComputerAssignment5 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class ComputerAssignment5
{
   public void main()
   { Scanner s =new Scanner(System.in);
       int n[] ={10,15,18,25,30,32,35,40,50};
       System.out.println("Enter Integer to be Searched: ");
       int num = s.nextInt(); //accepting an integer which needs to be searched
       int h =n.length;
       int idx = -1;
       for(int i=0; i<h-1;i++)
       { int m =(i+h)/2; //searching number using binary search
           if(n[m]==num)
           { idx=m;
               break;}
               else if(n[m]<num)
               {i=m+1;
                }
                else
                { h= m-1;
                }
            }
            if(idx==-1)
            System.out.println("Record Does Not Exist"); //printing the result
            else
            System.out.println("Record Exists");
        }
                   
}


/**
 * Write a description of class exam5 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class exam5
{ public void main()
    {Scanner s=new Scanner(System.in);
      
        System.out.println("Distance Covered By The Bus: ");
        double dist = s.nextDouble();
        double fare=0;
    {if (dist<=10)
         fare=80;
    else if(dist>11 && dist<20)
    fare =dist*6;
    else if(dist>21 && dist<30)
    fare = dist*5;
    else if(dist>=31)
    fare= dist*4;
    
}
              System.out.println("The Total Fare of the Trip is:" +fare);
}}

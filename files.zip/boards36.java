
/**
 * Write a description of class boards36 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class boards36
{
    public void main()
    {
        Scanner s = new Scanner (System.in);
        System.out.println("Enter Age of the Employee: ");
        int age = s.nextInt();
        System.out.println("Enter Gender of Employee: ");
        String gender = s.next();
        System.out.println("Enter Taxable Income: ");
        int inc = s.nextInt();
        double tax = 0.0;
        boolean k = gender.equalsIgnoreCase("female");
        if(k==true || age>65)
       { System.out.println("Wrong Category");
        }
     if(k==false && age<=65)
        {
            if(inc<=160000)
            tax = 0;
            else if(inc>160000 && inc<=500000)
            tax = (inc - 160000)*0.1;
            else if(inc>500000 && inc<=800000)
            tax = ((inc-500000)*0.2)+34000;
            else if(inc>800000)
            tax = ((inc-800000)*0.3)+94000;
        
        }
        System.out.println("The Tax on the Income is: " +tax);
    }
    
}

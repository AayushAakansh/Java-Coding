
/**
 * Amicable Number
 */
import java.util.*;
public class Boards30
{
    public void main()
{
    Scanner s = new Scanner(System.in);
    int sum1=0;
    int sum2=0;
    System.out.println("Enter Number 1: ");
    int num1 = s.nextInt();
    System.out.println("Enter Number 2: ");
    int num2 = s.nextInt();
    for(int i = 1; i<=num1; i++)
    {
        if(num1%i==0)
        sum1 = sum1+i;
    }
    for(int j=1; j<=num2; j++)
    {
        if(num2%j==0)
        sum2 = sum2+j;
    }
    if(sum1==num2 && sum2==num1)
    System.out.println("The Numbers are Amicable Numbers");
    else
    System.out.println("The Numbers are NOT Amicable Numbers");
}
}
   



/**
 * Write a description of class Boards8 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class Boards8
{
    public void main()
    { Scanner s = new Scanner(System.in);
        System.out.println("1. Triangle");
        System.out.println("2. Inverted Triangle");
        System.out.println("Enter your Choice: ");
        int cho = s.nextInt();
        
        switch(cho)
    {  
    case 1:
        for(int i = 1; i<=5; i++)
        { for(int j=1; j<=i; j++)
            { System.out.print(i + " ");
            }
        System.out.println();
    }
    break;
    case 2:
        for(int i = 5; i>=1; i--)
        { for(int j=1; j<=i; j++)
            { System.out.print(i + " ");
            }
            System.out.println();
        }
        break;
        default:
            System.out.println("Incorrect Choice");
        
    
}}}


/**
 * Write a description of class boards32 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class calculatorboards32
{
   private int result;
   calculatorboards32()
   {
       result=0;
   }
   void add(int a)
   {
       result=result+a;
   }
   void sum(int a)
   {
       result=result-a;
   }
   void mul(int a)
   {
       result=result*a;
   }
   void div(int a)
   {
       result=result/a;
   }
   void display()
   {
       System.out.println("The Result is: " +result);
   }
   void clear()
   {
       result=0;
   }
}


/**
 * Write a description of class switchcase3 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class switchcase3
{
    public void main()
    { Scanner sc= new Scanner(System.in);
        System.out.println("ENter a Number");
        double n= sc.nextDouble();
        System.out.println("1. Absolute value");
        System.out.println("2. Square Root");
        System.out.println("3. Cube Root");
        System.out.println("4. Square");
        System.out.println("Enter your Choice");
int a=sc.nextInt();
switch(a)
{ case 1: System.out.println("Aboslute Value = "+Math.abs(n));
    break;
    case 2: System.out.println("Square Root = "+Math.sqrt(n));
    break;
    case 3: System.out.println("Cube Root = "+Math.cbrt(n));
    break;
    
    case 4: System.out.println("Square = "+Math.pow(n,2));
    break;
    default : System.out.println("Invalid Choice");
}
}
}

/**
 * Write a description of class assign3 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class assign3
{public void main()
    {Scanner s = new Scanner(System.in);
        System.out.println("Enter a Number: ");
        int num= s.nextInt();
        System.out.print("Factors are: ");
        for(int i=1; i<=num; i++)
        {if(num%i==0)
            
            System.out.print(i+ ",");
        }}}
    


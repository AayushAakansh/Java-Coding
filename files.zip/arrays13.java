
/**
 * Write a description of class arrays13 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class arrays13
{
    public void main()
    { Scanner s=new Scanner(System.in);
        System.out.println("Enter Number of Students: ");
        int st=s.nextInt();
        int sum=0;
        String name[]= new String[st];
        int totalmarks[]=new int[st];
        for(int i=0;i<st;i++)
        {System.out.println("Enter Name of Student: ");
            name[i]=s.nextLine(); }
            for(int f=0;f<st;f++)
            {
            System.out.println("Enter The Total Marks: ");
            totalmarks[f]=s.nextInt();
        }
        for(int j=0;j<st;j++)
        {sum=sum+totalmarks[j];
            
        }
        int avg=sum/st;
        System.out.println("The Average of Marks: ");
        
        for(int m=0;m<st;m++)
        { int dev=totalmarks[m]-avg;
        }
    }
        
}


/**
 * Write a description of class Boards9 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class Boards9
{
    public void main()
    { Scanner s = new Scanner(System.in);
        System.out.println("Enter a Number: ");
        int num= s.nextInt();
        if(num%2==0)
        System.out.println("The Number is Even");
        else
        System.out.println("The Number is Odd");
        
    
}
}

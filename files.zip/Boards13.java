
/**
 FIBONACCI SERIES LESSGO!!!!!
 */
import java.util.*;
public class Boards13
{
    public void main()
    {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter Number of Series: ");
        int num = s.nextInt();
        int a=0;
        int b=1;
        int c;
        for(int i=1; i<=num; i++)
        { System.out.print(a + ",");
            c= a+b;
            a=b;
            b=c;
    }}
    
    
}

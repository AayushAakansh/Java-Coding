
/**
 * Write a description of class boards40 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class boards40
{
    public void main()
    {
        Scanner s = new Scanner(System.in);
        int m[] = new int[10];
        int ns;
        int lb=0;
        int ub=9;
        int p;
        int k=0;
        for(int i = 0 ; i<10; i++)
        {
            System.out.println("Enter Numbers in Array: ");
            m[i] = s.nextInt();
            
        }
        System.out.println("Enter Number to be Searched: ");
        ns = s.nextInt();
        while(lb<=ub)
        {
            p =(lb+ub)/2;
            if(m[p] < ns)
            lb = p+1;
            if(m[p]>ns)
            ub = p-1;
            if(m[p]==ns)
            {
                k=1; 
                break;
            }
        }
        if(k==1)
        System.out.println("The Number is Present");
        else
        System.out.println("The Number is not present");
    }
    
}

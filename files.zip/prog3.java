
/**
 * Write a description of class prog3 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class prog3
{ public void main()
    {Scanner s= new Scanner(System.in);
  System.out.println("Enter the Temperature Value");  /**Assigning variable for Temperature value given by user**/
  double tempvalue = s.nextDouble();
  System.out.println("Select your option: Fahrenheit to Celcius(+) or Celcius to Fahrenheit(-)"); /**giving option to user**/
  double answer=0;
  char converter= s.next().charAt(0);
  switch (converter)
  {case '+':
      answer= 5/9*(tempvalue-32);
      System.out.println("The Value in Celcius Scale is: " +answer); /**giving statements for both options**/
      break;
      case '-':
          answer =1.8*tempvalue+32;
          System.out.println("The Value in Fahrenheit Scale is: " +answer);
      break;
      default: System.out.println("The Option which you have chosen is Invalid");} /**end of switch statement**/
      
    
}}

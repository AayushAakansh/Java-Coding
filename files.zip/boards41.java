
/**
 * Write a description of class boards41 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class boards41
{
    public void main()
    {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter a Word in Upper Case: ");
        String word = s.nextLine();
        int l =word.length();
        char ch;
        for(int i =0; i<l; i++)
    {
        ch = word.charAt(i);
        System.out.println(ch);
    }
    }
   
}


/**
 * Write a description of class boards34 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class rectangleboards34
{
    int area;
    int perimeter;
    double diagonal;
    int length;
    int breadth;
    Scanner s = new Scanner(System.in);
    void inputdata()
    {
        System.out.println("Enter Length of Rectangle: ");
        length = s.nextInt();
        System.out.println("Enter Breadth of Rectangle: ");
        breadth = s.nextInt();
    }
    void calculate()
    {
         area = length * breadth;
        perimeter = 2*(length+breadth);
        diagonal =Math.sqrt((length*length)+(breadth*breadth)); 
    }
    void outputdata()
    {
        System.out.println("The Area is: " +area);
        System.out.println("The Perimeter is: " +perimeter);
        System.out.println("The Diagonal is: " +diagonal);
    }
    public void main()
    {
        rectangleboards34 ob = new rectangleboards34();
        ob.inputdata();
        ob.calculate();
        ob.outputdata();
    }
}


/**
 * Write a description of class thirdterm3 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class thirdterm3
{ public void main()
    {Scanner s = new Scanner(System.in);
      System.out.println("Enter an Integer: ");
      int num= s.nextInt();
      int upd;
      for(int i=1; i<=10; i++)
      { upd= num*i;
          System.out.print(upd+" , ");
        }
    
}}

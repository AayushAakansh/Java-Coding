
/**
 * Write a description of class ComputerAssignment1 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class ComputerAssignment1
{
    public static void main() 
    {
        
        Scanner in = new Scanner(System.in);
        String cities[] = new String[10]; //setting up arrays for stroing Cities and STD Codes
        String stdCodes[] = new String[10];
        System.out.println("Enter 10 cities and their STD codes:");
        
        for (int i = 0;  i < 10; i++) {
            System.out.print("Enter City Name: "); //seting up loop for accepting city name and respective STD codes
            cities[i] = in.nextLine();
            System.out.print("Enter its STD Code: ");
            stdCodes[i] = in.nextLine();
        }
        
        System.out.print("Enter name of city to search: "); //accepting city name to be searched
        String city = in.nextLine();
        
        int j;
        for (j = 0;  j < 10; j++) {
            if (city.compareToIgnoreCase(cities[j]) == 0) {
                break;
            } //going through the array
        }
        
        if (j < 10) {
            System.out.println("Search Successful");
            System.out.println("City: " + cities[j]);
            System.out.println("STD Code: " + stdCodes[j]);
        } //printing the results
        else {
            System.out.println("Search Unsuccessful");
        }
    }
}
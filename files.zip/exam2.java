
/**
 * Write a description of class exam2 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class exam2
{ public void main()
    {Scanner s= new Scanner(System.in);
      
        System.out.println("Printed Price of Mobile Phone: ");
        double pp= s.nextDouble();
        double discount = 0.1*pp;
        double ra= pp-discount;
        double GST = 0.09*ra;
        double total = GST+ra;
        System.out.println("Amount TO be Paid is: " +total);
        
    
}}


/**
 * Write a description of class ComputerAssignment4 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class ComputerAssignment4
{public void main()
    { Scanner s= new Scanner(System.in);
        int temp;
        int arr[]=new int[15];
        System.out.println("Enter 15 Numbers: ");
        for(int i=0;i<15;i++) //accepting 15 numbers
        { arr[i]= s.nextInt();
        }
        for(int i=0; i<14;i++) //setting up loop for arrainging the Number in ascending order 
        { for(int j=0;j<14-i;j++)
            { if(arr[j]>arr[j+1])
                {temp=arr[j];
                    arr[j]=arr[j+1];
                    arr[j+1]=temp;
                }}}
                System.out.println("Elements in Ascending Order are: ");
                for(int i=0;i<15;i++) //printing the resulted ascending order
                { System.out.println(arr[i]);
                }}}
                
    

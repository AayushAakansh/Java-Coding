
/**
 * Write a description of class thirdterm6 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class thirdterm6
{ public void main()
    {Scanner s = new Scanner(System.in);
        System.out.println("Enter a Number: ");
        int num= s.nextInt();
        int reverse=0;
        int remain=0;
        while(num>0)
        { remain = num%10;
            reverse= reverse*10 + remain;
            num/=10;
        }
        System.out.println("Reversed Number is: " +reverse);
    }
    
}

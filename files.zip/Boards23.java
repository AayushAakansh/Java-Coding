
/**
 * Write a description of class Boards23 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class Boards23
{
    public void main()
    {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter a Number: ");
        int num= s.nextInt();
        boolean flag=true;
        while(num!=1)
        {
            if(num%2==0)
            {
                
            num=num/2;
        }
        else if(num%3==0)
        {
            num=num/3;
        }
        else if(num%5==0)
        {
            num=num/5;
        }
        else
        {
            flag=false;
            break;
        }
        
        }
        if(flag)
        System.out.println("The Number is an Ugly Number");
        else
        System.out.println("The Number is not an Ugly Number");
    }
    
}

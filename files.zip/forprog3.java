
/**
 * Write a description of class forprog3 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class forprog3
{
    public void main()
    { Scanner s = new Scanner(System.in);

   int i=0;
   int m=0;
   for(i=1;i<=10;i++)
   { m+=i;
       System.out.println(m);
   
}}}

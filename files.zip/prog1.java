
/**
 * Write a description of class prog1 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class prog1
{
    public void main()
    {
    Scanner s = new Scanner(System.in);
    System.out.println("Age of the Person");
    int age = s.nextInt();
    System.out.println("Gender of the Person M for male and F for female");
    char gen = s.next().charAt(0);
    /**Printing age,gender of person**/

    /** checking if person is not female and not above 65 yrs **/
    if( gen== 70 || age>65)
    System.out.println("Wrong Category");
    
    System.out.println("Taxable Income of the Person");
    double TI = s.nextDouble();  /**assigning variable for TAxable income and for Income tax**/
    double incomeT = 0;
    /**Checking Different Conditons**/
    {
    if(TI<160000)                           
    {System.out.println("No Tax");}
    else if(TI>160000 && TI<=500000)
    {incomeT = (TI - 160000)*0.1;
     }
    else if(TI>500000 && TI<=800000)
    {incomeT = ((TI-500000)*0.2) +34000;
     }
    else if(TI>800000)
    incomeT = ((TI-800000)*0.3) +94000;
    }
           System.out.println("Income Tax to be Paid is " +incomeT);/**Printing Income Tax Amount**/
                         
    
    }}
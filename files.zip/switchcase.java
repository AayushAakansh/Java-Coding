
/**
 * Write a description of class switchcase here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

    import java.util.*;

public class switchcase 
{ public void main()
    {
    Scanner s= new Scanner(System.in);
    System.out.println("1. Red");
    System.out.println("2. Green");
    System.out.println("3. Blue");
    System.out.println("Enter Choice 1,2 or 3");}
    int a;
    {switch(a)
    {
      case 1:System.out.println("You have chosen Red Colour");
      break;
      case 2:System.out.println("You have chosen Green Colour");
      break;
      
      case 3:System.out.println("You have chosen Blue Colour");
      break;
      default: System.out.println("Invalid Option");
}}}
